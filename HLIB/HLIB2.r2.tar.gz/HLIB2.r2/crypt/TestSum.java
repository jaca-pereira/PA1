import java.math.BigInteger;

import hlib.hj.mlib.HelpSerial;
import hlib.hj.mlib.HomoAdd;
import hlib.hj.mlib.PaillierKey;

public class TestSum {

	public static void main(String[] args) {

		try {
			PaillierKey pk = HomoAdd.generateKey();
			//pk.printValues();
                        System.out.println("-----------------------------");					   
		        System.out.println("Dois big integers para somar ...");
			BigInteger big1 = new BigInteger("1122");
			BigInteger big2 = new BigInteger("1245");
		        BigInteger bigsum= big1.add(big2);
		   
			System.out.println("big1 Plaintext:     "+big1);
			System.out.println("big2 Plaintext:     "+big2);
		        System.out.println("Sum  Plaintext:     "+bigsum);
		   
   			BigInteger big1Code = HomoAdd.encrypt(big1, pk);
			BigInteger big2Code = HomoAdd.encrypt(big2, pk);

                        System.out.println("-----------------------------");					   
		        System.out.println("cifra de "+big1);
                        System.out.println("-----------------------------");
			System.out.println("big1Code: "+big1Code);
                        System.out.println("-----------------------------");
		        System.out.println("cifra de " +big2);
                        System.out.println("-----------------------------");		     
			System.out.println("big2Code: "+big2Code);
		   
                        System.out.println("-----------------------------");
		        System.out.println("Vamos somar os numeros cifrados");
                        System.out.println("-----------------------------");
		   
			BigInteger big3Code = HomoAdd.sum(big1Code, big2Code, pk.getNsquare());

                        System.out.println("-----------------------------");
		        System.out.println("Eis a soma cifrada ...");
                        System.out.println("-----------------------------");		   		   
			System.out.println("big3Code: "+big3Code);		   
		   
                        System.out.println("-----------------------------");
		        System.out.println("Vamos decifrar a soma cifrada");
                        System.out.println("-----------------------------");		   
			BigInteger big3 = HomoAdd.decrypt(big3Code, pk);
			System.out.println("Resultado = "+big3.intValue());

		        System.out.println();
                        System.out.println("-----------------------------");
		        System.out.println("Teste: tb suporta subtraccao");
                        System.out.println("-----------------------------");		   		   

			BigInteger op1 = new BigInteger("1245");
			System.out.println("Op1 ="+op1);
			BigInteger op2 = new BigInteger("1122");
			System.out.println("Op2 ="+op2);
			BigInteger op1Code = HomoAdd.encrypt(op1, pk);
			BigInteger op2Code = HomoAdd.encrypt(op2, pk);	
			BigInteger op3Code = HomoAdd.dif(op1Code, op2Code, pk.getNsquare());	
			// Test key serialization
			String chaveGuardada ="";

			chaveGuardada = HelpSerial.toString(pk);

			//System.out.println("Chave guardada: "+chaveGuardada);
			// Test with saved key
			PaillierKey pk2 = null;
			BigInteger op3 = null;
			pk2 = (PaillierKey) HelpSerial.fromString(chaveGuardada);
			op3 = HomoAdd.decrypt(op3Code, pk2);
		   

			System.out.println("Subtracao: "+op3);
		} catch (Exception e) {
			e.printStackTrace();
		}


	}

}
