
import javax.crypto.SecretKey;

import hlib.hj.mlib.HelpSerial;
import hlib.hj.mlib.HomoSearch;

public class TestSearch {

	public static void main(String[] args) {
		String texto = "palavra8 palavra1 palavra2 palavra3 palavra4 palavra1";
		System.out.println("Plaintext: "+texto);
	   
	        String palavra = "palavra1";
		String subTexto = "palavra2 palavra4";
	   
	        System.out.println("Geracao de have para homomorphic search ... ");
		SecretKey key = HomoSearch.generateKey();

	        System.out.println();
	        System.out.println("Cifrar homomorficamente o Input");
	   
		String resultado = HomoSearch.encrypt(key , texto);
	        System.out.println("Ciphertext: "+resultado);
	        System.out.println();	   
	   
   	        System.out.println("Pesquisar: "+palavra);
		String palavraEnc = HomoSearch.wordDigest64(key, palavra);
		if (HomoSearch.pesquisa(palavraEnc, resultado)) 
	              System.out.println("A palavra "+palavra+" existe");
		   else 
	              System.out.println("A palavra "+palavra+" nao existe");

                System.out.println();

   	        System.out.println("Pesquisar subtexto:"+subTexto);
		if (HomoSearch.searchAll(HomoSearch.encrypt(key, subTexto), resultado)) 
	           System.out.println("O subtexto "+subTexto+" existe");
		   else 
	           System.out.println("O subtexto "+subTexto+" nao existe");

   	        System.out.println();	   	   
		String chaveGuardada = HelpSerial.toString(key);
		System.out.println("Chave guardada: "+chaveGuardada);
		// Test with saved key
		SecretKey key2 = (SecretKey) HelpSerial.fromString(chaveGuardada);
		String retorno = HomoSearch.decrypt(key2, resultado);
	   
   	        System.out.println();	   
	        System.out.println("Recuperacao: "+retorno);

	}

}
